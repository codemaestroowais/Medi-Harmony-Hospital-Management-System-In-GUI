﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary.Utilitys
{
    public class Utility
    {
        //This is the database connection string
        private static string conn = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=SignInSignUp;Integrated Security=True";
        public static string GetConnectionString() 
        { 
            return conn; 
        }
    }
}
