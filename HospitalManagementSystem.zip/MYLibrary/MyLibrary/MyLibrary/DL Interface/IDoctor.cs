﻿using MyLibrary.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary.DL_Interface
{
    public interface IDoctor
    {
        //This function add data to database/file
        bool AddDoctor(DoctorBL doctor);
        //This function return the list of doctors data in the database
        List<DoctorBL> ViewDoctor();
        DoctorBL GetDoctorName(string name);
        bool UpdateDoctor(string PatientCNIC, DoctorBL doctor);
        bool RemoveDoctor(string doctorName, string doctorSpeciality);
        bool SelectDoctor(string doctorname, string doctorspeciality, string date, string gmail);
        (List<DoctorBL>, List<string>) ViewSelectedDoctor(string gmail, string date1);
        bool RemoveSelectedDoctor(string Date);

    }
}
