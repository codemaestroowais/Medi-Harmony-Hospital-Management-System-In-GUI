﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyLibrary.BL;
using MyLibrary.DL_Interface;
using MyLibrary.Utilitys;

namespace MyLibrary.DL_Interface
{
    public interface IPatientAdded
    {
        //This function add data to data base\file
        bool AddPatient(PatientAdded patient);
        //This Function get data from dtaa base
        List<PatientAdded> ViewPatient();
        //this fiunction search bu cnic
        PatientAdded GetPatient(string CNIC);
        //this function update the patient by cnic
        bool UpdatePatient(string PatientCNIC, PatientAdded patient);
        //this function remove the patient
        bool RemovePatient(string PatientCNIC);
    }
}
