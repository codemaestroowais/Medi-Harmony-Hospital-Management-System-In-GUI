﻿using MyLibrary.BL;
using MyLibrary.DL_Interface;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary.DL.DB
{
    public class MedicineDL : IMedicine
    {
        private string conn = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=SignInSignUp;Integrated Security=True";
        public MedicineDL(string conn)
        {
            this.conn = conn;
        }

        public bool AddMedicine(Medicines medicine)
        {
            string query = String.Format("Insert into Medicine(Name,Quantity,BatchNumber) values('{0}','{1}','{2}')"
                , medicine.GetMedicineName(), medicine.GetMedicineQuantity(), medicine.GetMedicineBatchNo());
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            int rows = sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            if (rows > 0)
            {
                return true;
            }
            return false;
        }
        public List<Medicines> ViewMedicine()
        {
            List<Medicines> medicine = new List<Medicines>();
            string query = "Select * from Medicine";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            while (reader.Read())
            {
                Medicines medicine1 = new Medicines(Convert.ToString(reader["Name"]), Convert.ToInt32(reader["Quantity"]), 
                    Convert.ToInt32(reader["BatchNumber"]));
                medicine.Add(medicine1);
            }
            reader.Close();
            sqlConnection.Close();
            return medicine;
        }
        public Medicines GetMedicine(int MedicineBatchNo)
        {
            string query = String.Format("Select * from Medicine where BatchNumber='{0}'", MedicineBatchNo);
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            if (reader.Read())
            {
                Medicines medicine = new Medicines(Convert.ToString(reader["Name"]), Convert.ToInt32(reader["Quantity"]), 
                    Convert.ToInt32(reader["BatchNumber"]));
                reader.Close();
                sqlConnection.Close();
                return medicine;
            }
            reader.Close();
            sqlConnection.Close();
            return null;
        }
        public bool UpdateMedicine(int MedicineBatchNo, Medicines medicine)
        {
            string query = String.Format("Update Medicine set Name = '{0}',Quantity = '{1}'" +
                " where BatchNumber = '{2}'", medicine.GetMedicineName(), medicine.GetMedicineQuantity(), 
                 MedicineBatchNo);
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            int rows = sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            if (rows > 0)
            {
                return true;
            }
            return false;
        }
        public bool BuyMedicine(string MedicineName , int MedicineQuantity) 
        {
            int Quantity = GetMedicineQuantity(MedicineName);
            string query = String.Format("Update Medicine set Quantity = '{0}'" +
                " where Name = '{1}'", MedicineQuantity, MedicineName);
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            int rows = sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            if (rows > 0)
            {
                return true;
            }
            return false;
        }
        public int GetMedicineQuantity(string MedicineName)
        {
                string ShopsString = null;
                int Shops = 0;
                SqlConnection connection = new SqlConnection(conn);
                connection.Open();

                string searchQuery = String.Format("Select Quantity from Medicine where Name = '{0}'", MedicineName);
                SqlCommand command = new SqlCommand(searchQuery, connection);
                object data = command.ExecuteScalar();
                if (data != null)
                {
                    ShopsString = data.ToString();
                    connection.Close();
                    Shops = int.Parse(ShopsString);

                }

                connection.Close();
                return Shops;
        }
        public bool RemoveMedicine(int MedicineBatchNo)
        {
            string query = String.Format("Delete from Medicine where BatchNumber ='{0}'", MedicineBatchNo);
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sql = new SqlCommand(query, sqlConnection);
            int rows = sql.ExecuteNonQuery();
            sqlConnection.Close();
            if (rows > 0)
            {
                return true;
            }
            return false;
        }
    }
}
