﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary.BL
{
    public class PatientBL : MUserBL
    {
        //Attributes
        private Billing_Invoice Bill;
        private PatientReview Review;
        //Constructor
        public PatientBL(string Name, string Gender, string UserName, string Password, string Role) : base(Name,
            Gender, UserName, Password, Role) { }
        //Getter
        public void SetBill(Billing_Invoice Bill) {  this.Bill = Bill; }
        public void SetReview(PatientReview Review) {  this.Review = Review; }
        //Setter
        public Billing_Invoice GetBill() { return this.Bill; }
        public PatientReview GetReview() {  return this.Review; }
    }
}
