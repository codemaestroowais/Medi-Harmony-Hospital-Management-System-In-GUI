﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary.BL
{
    public class PatientAdded
    {
        //Attributes
        private string PatientName;
        private int PatientAge;
        private string PatientCNIC;
        private string PatientPhoneNo;
        private string PatientHistory;
        //Constructor
        public PatientAdded() { }
        public PatientAdded(string patientName, int patientAge, string patientCNIC, string patientPhoneNo, string patientHistory)
        {
            PatientName = patientName;
            PatientAge = patientAge;
            PatientCNIC = patientCNIC;
            PatientPhoneNo = patientPhoneNo;
            PatientHistory = patientHistory;
        }
        //Setter
        public void SetPatientName(string patientName) {  PatientName = patientName; }
        public void SetPatientAge(int patientAge) { PatientAge = patientAge; }
        public void SetPatientCNIC(string  patientNIC) { PatientCNIC = patientNIC; }
        public void SetPatientPhoneNo(string patientPhoneNo) { PatientPhoneNo = patientPhoneNo; }
        public void SetPatientHistory(string  history) { PatientHistory = history; }
        //Getter
        public string GetPatientName() { return PatientName;}
        public int GetPatientAge() {  return PatientAge;}
        public string GetPatientCNIC() { return PatientCNIC; }
        public string GetPatientPhoneNo() {  return PatientPhoneNo;}
        public string GetPatientHistory() {  return PatientHistory;}
    }
}
