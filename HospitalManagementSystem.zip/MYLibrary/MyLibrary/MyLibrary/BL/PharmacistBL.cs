﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary.BL
{
    public class PharmacistBL : MUserBL
    {
        //Attributes
        private List<Medicines> MedicineList = new List<Medicines>();
        private List<EmplyBL> EmployList = new List<EmplyBL>();
        //Constructor
        public PharmacistBL(string Name, string Gender, string UserName, string Password, string Role) : base(Name, Gender, UserName, Password, Role) { }
        //Setter
        public void AddMedicinesIntoList(Medicines medicines) { MedicineList.Add(medicines);}
        public void AddEmployIntoList(EmplyBL employ) {  EmployList.Add(employ);}
        //Getter
        public List<Medicines> GetMedicinesList()
        {
            return MedicineList;
        }
        public List<EmplyBL> GetEmployList()
        {
            return EmployList;
        }
    }
}
