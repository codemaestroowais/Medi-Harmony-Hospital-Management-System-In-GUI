﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary.BL
{
    public class DoctorBL
    {
        //Attributes
        private string DoctorName;
        private string DoctorSpeciality;
        private string DoctorStatus;
        //Constructor
        public DoctorBL(string doctorName, string doctorSpeciality)
        {
            DoctorName = doctorName;
            DoctorSpeciality = doctorSpeciality;
        }
        public DoctorBL(string doctorName, string doctorSpeciality, string Status)
        {
            DoctorName = doctorName;
            DoctorSpeciality = doctorSpeciality;
            this.DoctorStatus= Status;
        }
        //Setter
        public void SetDoctorName(string DoctorName) { this.DoctorName = DoctorName; }
        public void SetDoctorStatus(string DoctorStatus) { this.DoctorStatus = DoctorStatus; }
        public void SetDoctorSpeciality(string DoctorSpeciality) { this.DoctorSpeciality = DoctorSpeciality; }
        //Getter
        public string GetDoctorName() { return this.DoctorName; }
        public string GetDoctorStatus() { return this.DoctorStatus; }
        public string GetDoctorSpeciality() { return this.DoctorSpeciality; }
    }
}
