﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary.BL
{
    public class Billing_Invoice
    {
        //Attributes
        private int NoOfDaysStayed;
        private string RoomType;
        private string EmergencyState;
        //Constructor
        public Billing_Invoice() { }
        public Billing_Invoice(int noOfDaysStayed, string roomType, string emergencyState)
        {
            NoOfDaysStayed = noOfDaysStayed;
            RoomType = roomType;
            EmergencyState = emergencyState;
        }
        //Setter
        public void SetNoOfDaysStayed(int noOfDaysStayed) { this.NoOfDaysStayed = noOfDaysStayed; }
        public void SetRoomType(string RoomType) { this.RoomType = RoomType;}
        public void SetEmergencyState(string EmergencyState) {  this.EmergencyState = EmergencyState;}
        //Getter
        public int GetNoOfDaysStayed() {  return NoOfDaysStayed;}
        public string GetRoomType() {  return RoomType;}
        public string GetEmergencyState() {  return EmergencyState;}
    }
}
