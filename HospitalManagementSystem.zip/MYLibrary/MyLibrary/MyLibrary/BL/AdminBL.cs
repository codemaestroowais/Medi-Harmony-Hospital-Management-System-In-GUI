﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary.BL
{
    public class AdminBL : MUserBL
    {
        //Attributes

        private List<PatientAdded> PatientList = new List<PatientAdded>();
        private List<DoctorBL> DoctorList = new List<DoctorBL>();
        private int AddBed;
        private int PatientIndex = 0;

        //Constructor
        public AdminBL(string Name, string Gender, string UserName, string Password, string Role) : base(Name, Gender, UserName, Password, Role)
        {
            
        }
        //Setter
        public void AddPatientIntoList(PatientAdded Patient)
        {
            PatientList.Add(Patient);
        }
        public void SetDoctorList(DoctorBL Doctors) { DoctorList.Add(Doctors); }
        public void SetAddBed(int AddBed)
        { this.AddBed = AddBed; }
        public void SetPatientIndex(int PatientIndex)
        { this.PatientIndex = PatientIndex;} 
        //Getter
        public int GetAddBed() { return this.AddBed;}
        public int GetPatientIndex() { return this.PatientIndex; }
        public List<PatientAdded> GetPatientList()
        {
            return PatientList;
        }
        public List<DoctorBL> GetDoctorList() {  return DoctorList; }
    }
}
