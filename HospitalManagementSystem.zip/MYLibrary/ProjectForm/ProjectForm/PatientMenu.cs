﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectForm
{
    public partial class PatientMenu : Form
    {
        public PatientMenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Patient_Review patient_Review = new Patient_Review();
            this.Hide();
            patient_Review.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ViewDoctor viewDoctor = new ViewDoctor();
            this.Hide();
            viewDoctor.ShowDialog();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            SignIn signIn = new SignIn();
            this.Hide();
            signIn.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Handy_Beds handy_Beds = new Handy_Beds();
            this.Hide();
            handy_Beds.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Select_Doctor s=new Select_Doctor();
            this.Hide();
            s.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Billing_and_Invoice billing_And_Invoice = new Billing_and_Invoice();
            this.Hide();
            billing_And_Invoice.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            View_Prescription view_Prescription = new View_Prescription();
            this.Hide();
            view_Prescription.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            ViewSelectedDoctor viewSelectedDoctor= new ViewSelectedDoctor();
            this.Hide();
            viewSelectedDoctor.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            BuyMedicine buyMedicine = new BuyMedicine();
            this.Hide();
            buyMedicine.ShowDialog();
        }
    }
}
