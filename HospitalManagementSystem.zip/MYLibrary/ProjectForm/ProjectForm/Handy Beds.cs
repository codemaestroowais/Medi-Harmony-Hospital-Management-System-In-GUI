﻿using MyLibrary.DL.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectForm
{
    public partial class Handy_Beds : Form
    {
        public Handy_Beds()
        {
            InitializeComponent();
            string path = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=SignInSignUp;Integrated Security=True";
            AdminDL a = new AdminDL(path);
            textBox1.Text=a.GetBeds(SignIn.GetUSERUSERNAME()).ToString();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Console.WriteLine();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            PatientMenu patient = new PatientMenu();
            this.Hide();
            patient.ShowDialog();
        }
    }
}
