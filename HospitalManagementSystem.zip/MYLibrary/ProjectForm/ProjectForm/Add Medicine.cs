﻿using MyLibrary.BL;
using MyLibrary.DL.DB;
using MyLibrary.DL_Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ProjectForm
{
    public partial class Add_Medicine : Form
    {
        public Add_Medicine()
        {
            InitializeComponent();
        }

        private void Add_Medicine_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string path = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=SignInSignUp;Integrated Security=True";
            int a = int.Parse(textBox2.Text);
            int b = int.Parse(textBox3.Text);
            
            IMedicine medicine = new MedicineDL(path);
            Medicines user1 = null;
            user1 = new Medicines(textBox1.Text, a, b);
            Medicines patientAdded = (Medicines)user1;
            medicine.AddMedicine(user1);
            MessageBox.Show("The Patient is added successfully.");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Pharmacist pharmacist = new Pharmacist();
            this.Hide();
            pharmacist.ShowDialog();
        }
    }
}
