﻿using MyLibrary.BL;
using MyLibrary.DL.DB;
using MyLibrary.DL_Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectForm
{
    public partial class SignIn : Form
    {
        private static string UserUsername;
        public static void SetUSERUSERNAME(string username)
        {
            UserUsername = username;
        }
        public static string GetUSERUSERNAME()
        {
            return UserUsername;
        }
        public SignIn()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SignUp signupform = new SignUp();
            this.Hide();
            signupform.ShowDialog();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string path = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=SignInSignUp;Integrated Security=True";
            IUser user = new MUserDL(path);
            MUserBL U = new MUserBL(textBox1.Text, textBox2.Text);
            U = user.SignIn(U);
            if(U != null)
            {
                SetUSERUSERNAME(U.GetUserName());
                
                if(U.GetRole() == "Admin")
                {
                    AdminMenu adminMenu = new AdminMenu();
                    this.Hide();
                    adminMenu.ShowDialog();
                }
                else if(U.GetRole() == "Patient")
                {
                    PatientMenu patientMenu = new PatientMenu();
                    this.Hide();
                    patientMenu.ShowDialog();
                }
                else if( U.GetRole() == "Pharmacist")
                {
                    Pharmacist pharmacistmenu = new Pharmacist();
                    this.Hide();
                    pharmacistmenu.ShowDialog();
                }
            }
            else
            {
                MessageBox.Show("Such type of user not exists.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void SignIn_Load(object sender, EventArgs e)
        {

        }
    }
}
