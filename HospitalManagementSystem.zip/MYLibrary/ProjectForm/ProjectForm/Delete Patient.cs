﻿using MyLibrary.DL.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectForm
{
    public partial class Delete_Patient : Form
    {
        public Delete_Patient()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AdminMenu adminMenu = new AdminMenu();
            this.Hide();
            adminMenu.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            PatientAddedDL p = new PatientAddedDL();
            if(p.RemovePatient(textBox1.Text) == true)
            {
                MessageBox.Show("The Patient with this CNIC has been discharge.");
            }
            else
            {
                MessageBox.Show("This patient is not in our record.");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
    }
}
