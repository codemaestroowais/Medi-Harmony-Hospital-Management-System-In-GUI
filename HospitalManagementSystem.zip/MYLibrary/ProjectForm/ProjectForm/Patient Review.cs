﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectForm
{
    public partial class Patient_Review : Form
    {
        public Patient_Review()
        {
            InitializeComponent();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thanks for your review. We will try our best to provide you modern facilities.");
        }

        private void button12_Click(object sender, EventArgs e)
        {
            PatientMenu patientMenu = new PatientMenu();
            this.Hide();
            patientMenu.ShowDialog();
        }
    }
}
