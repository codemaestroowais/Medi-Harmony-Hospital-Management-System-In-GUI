﻿using MyLibrary.BL;
using MyLibrary.DL.DB;
using MyLibrary.DL_Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ProjectForm
{
    public partial class ViewDoctorAdmin : Form
    {
        static string path = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=SignInSignUp;Integrated Security=True";
        IDoctor doctor = new DoctorDL(path);
        DataTable dataTable1 = new DataTable();
        public ViewDoctorAdmin()
        {
            InitializeComponent();
            dataTable1.Columns.Add("Name");
            dataTable1.Columns.Add("Speciality");
            List<DoctorBL> p;
            p = doctor.ViewDoctor();
            foreach (DoctorBL d in p)
            {
                dataTable1.Rows.Add(d.GetDoctorName(), d.GetDoctorSpeciality());
            }
            dataGridView1.DataSource = dataTable1;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            AdminMenu adminMenu = new AdminMenu();
            this.Hide();
            adminMenu.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ViewDoctorAdmin_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DoctorBL p = doctor.GetDoctorName(textBox1.Text);
            if (p != null)
            {
                textBox5.Text = p.GetDoctorName();
                textBox2.Text = p.GetDoctorSpeciality();
            }
            else
            {
                MessageBox.Show("The doctor with this name is not in our record.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataGridViewRow Row = null;
            DoctorBL doctor1 = new DoctorBL(textBox5.Text, textBox2.Text);
            if (doctor.UpdateDoctor(textBox5.Text, doctor1))
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    // Assuming the CNIC is in the first cell of each row
                    if (row.Cells[2].Value != null && row.Cells[2].Value.ToString() == textBox5.Text)
                    {
                        // Select the row if the CNIC matches
                        row.Selected = true;
                        // Optionally, you can scroll to the selected row
                        dataGridView1.FirstDisplayedScrollingRowIndex = row.Index;
                        Row = row;

                        break; // Exit the loop once the row is found
                    }
                }
                Row.Cells[0].Value = textBox5.Text;
                Row.Cells[1].Value = textBox2.Text;
            }
            else
            {
                MessageBox.Show("Unable to Update");
            }
        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            AdminMenu adminMenu = new AdminMenu();
            this.Hide();
            adminMenu.Show();
        }
    }
}
