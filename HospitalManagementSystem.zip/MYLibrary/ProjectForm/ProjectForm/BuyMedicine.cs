﻿using MyLibrary.BL;
using MyLibrary.DL.DB;
using MyLibrary.DL_Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ProjectForm
{
    public partial class BuyMedicine : Form
    {
        static string path = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=SignInSignUp;Integrated Security=True";

        MedicineDL medicineDL = new MedicineDL(path);
        DataTable dataTable = new DataTable();
        int SelectedRow;
        int TotalQuantity=0;
        public BuyMedicine()
        {
            InitializeComponent();
            dataTable.Columns.Add("Name");
            dataTable.Columns.Add("Quantity");
            dataTable.Columns.Add("BatchNumber");
            List<Medicines> list;
            list = medicineDL.ViewMedicine();

            foreach (Medicines m in list)
            {
                dataTable.Rows.Add(m.GetMedicineName(), m.GetMedicineQuantity(),m.GetMedicineBatchNo());
            }
            Table1.DataSource = dataTable;
        }

        private void Table1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (Quantitytxt.Text != null)
            {

                if (int.Parse(Quantitytxt.Text) < TotalQuantity)
                {
                    SelectedRow = Table1.CurrentCell.RowIndex;
                    DataGridViewRow row = Table1.Rows[SelectedRow];
                    medicineDL.BuyMedicine(Nametxt.Text, TotalQuantity - int.Parse(Quantitytxt.Text));
                    row.Cells[1].Value = TotalQuantity - int.Parse(Quantitytxt.Text);
                    MessageBox.Show("Product Bought");
                }
                else
                {
                    MessageBox.Show("Not Enough Quanity");
                }

            }
            else
            {
                MessageBox.Show("Enter Some Quantity");
            }
        }

        private void Quantitytxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void Pricetxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void Nametxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            PatientMenu patientMenu = new PatientMenu();
            this.Hide();
            patientMenu.ShowDialog();
        }

        private void BuyMedicine_Load(object sender, EventArgs e)
        {

        }

        private void Table1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            SelectedRow = Table1.CurrentCell.RowIndex;
            if (SelectedRow >= 0)
            {
                DataGridViewRow row = Table1.Rows[SelectedRow];
                Nametxt.Text = row.Cells[0].Value.ToString();
                Pricetxt.Text = row.Cells[2].Value.ToString();
                TotalQuantity = int.Parse(row.Cells[2].Value.ToString());
                

            }
        }
    }
}
