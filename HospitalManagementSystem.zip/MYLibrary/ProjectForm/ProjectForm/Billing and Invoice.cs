﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectForm
{
    public partial class Billing_and_Invoice : Form
    {
        public Billing_and_Invoice()
        {
            InitializeComponent();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
           Bill_Slip_Menu bill_Slip_Menu = new Bill_Slip_Menu();
            this.Hide();
            bill_Slip_Menu.ShowDialog();
        }
    }
}
